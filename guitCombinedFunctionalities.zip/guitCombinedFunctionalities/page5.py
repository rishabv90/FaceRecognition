# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\risha\OneDrive\Desktop\faceRecGui\guiTest\guitTest1\page5.ui'
# README: This page is when a user has been successful been logged in as "admin", all the actions that an admin can take will show up here
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PySide2 import QtCore, QtGui, QtWidgets
import page1, page6, page7


class Ui_MainWindow(object):
    def __init__(self, name):
        self._name = name

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1139, 904)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(450, 80, 231, 171))
        self.label.setObjectName("label")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(930, 780, 151, 41))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(450, 300, 231, 91))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(450, 420, 231, 91))
        self.pushButton_3.setObjectName("pushButton_3")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(410, 0, 321, 101))
        self.label_2.setObjectName("label_2")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1139, 21))
        self.menubar.setObjectName("menubar")
        self.menuExit = QtWidgets.QMenu(self.menubar)
        self.menuExit.setObjectName("menuExit")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menubar.addAction(self.menuExit.menuAction())
        #button press
        self.pushButton_2.clicked.connect(self.goToPage1) #logout
        self.pushButton.clicked.connect(self.goToPage6) #create new user
        self.pushButton_3.clicked.connect(self.goToPage7) #view user list
       
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p><img src=\"Webp.net-resizeimage.jpg\"/></p></body></html>"))
        self.pushButton_2.setText(_translate("MainWindow", "Logout"))
        self.pushButton.setText(_translate("MainWindow", "Create New User"))
        self.pushButton_3.setText(_translate("MainWindow", "View User List"))
        self.label_2.setStyleSheet(_translate("MainWindow", "font-size:18pt; font-weight:600;"))
        self.label_2.setText(_translate("MainWindown", "Admin - " + self._name + "'s Page"))
        self.menuExit.setTitle(_translate("MainWindow", "Exit"))
        #import rochePic_rc

    def goToPage1(self):#logout button
        #MainWindow.close()
        MainWindow.hide()
        print("go back to main page")
        self.window = QtWidgets.QMainWindow()
        self.ui =  page1.Ui_MainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def goToPage6(self):
        #MainWindow.close()
        MainWindow.hide()
        print("go to create new user page")
        self.window = QtWidgets.QMainWindow()
        self.ui =  page6.Ui_MainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def goToPage7(self):
        #MainWindow.close()
        MainWindow.hide()
        print("go to view user list")
        self.window = QtWidgets.QMainWindow()
        self.ui =  page7.Ui_MainWindow7(name)
        self.ui.setupUi(self.window)
        self.window.show()


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow("Empty")
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
